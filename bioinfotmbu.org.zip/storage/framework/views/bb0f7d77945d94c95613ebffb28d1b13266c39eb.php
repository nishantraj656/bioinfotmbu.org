<?php /* C:\xampp\htdocs\bioinfotmbu.org\resources\views/MainHome.blade.php */ ?>
<?php $__env->startSection('title', 'University Center of Bio-Informatics'); ?>

<?php $__env->startSection('content'); ?>
    <P>Hello sir g</P>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>