@extends('Home')

@section('title', 'University Center of Bio-Informatics')

@section('content')
    <P>Hello sir g</P>
@endsection